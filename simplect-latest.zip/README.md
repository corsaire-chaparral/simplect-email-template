# Simplect: e-mail template

A simple and nice e-mail template (for Mautic).

## How to make it yours

- Clone
- Edit `kit/_variables.kit` (it' a [Kit file](https://codekitapp.com/help/kit/))
- Compile (with [Prepros](https://prepros.io), for example)
- Zip everything
- Post the zip to your Mautic (on `Config > Themes`)

... Or you can just use as it is.

I undestand that this is not an easy process, but it was the easier one found to allow customization.

## How it looks
![Screenshot](https://raw.githubusercontent.com/hmaesta/simplect-email-template/master/thumbnail.png)

[See real size screenshot](https://raw.githubusercontent.com/hmaesta/simplect-email-template/master/images/simplect-full-preview.png)

### Credits

It' based on [Cerberus](https://github.com/TedGoas/Cerberus).